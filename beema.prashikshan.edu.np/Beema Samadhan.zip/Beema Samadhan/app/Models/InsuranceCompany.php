<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InsuranceCompany extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'address', 'description', 'logo', 'insurance_type'];

    public function products()
    {
        return $this->hasMany(InsuranceProduct::class, 'company_id');
    }
}
